<?php
/**
 * Content wrappers
 *
* @author 	TommusRhodus
* @package 	Slowave
* @version   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$template = get_option( 'template' );

echo '<div class="dark-wrapper">
  <div class="container inner">
    <div class="row">';