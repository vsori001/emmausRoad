<?php
/**
* @author 		TommusRhodus
* @package 	Slowave
* @version     1.0.0
 */

echo ( is_active_sidebar('shop') ) ? '</div></div>' : '</div>';