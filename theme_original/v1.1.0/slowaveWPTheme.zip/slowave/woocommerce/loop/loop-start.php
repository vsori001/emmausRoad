<?php
/**
* @author 		TommusRhodus
* @package 	Slowave
* @version     1.0.0
 */
 
echo ( is_active_sidebar('shop') ) ? '<div class="products col-sm-8 content"><div class="grid-blog col2">' : '<div class="grid-blog col3 products">';