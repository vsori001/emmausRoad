<div class="navigation pull-right"> 
	<?php
		previous_post_link('%link', "<i class='icon-left-open-1'></i>" );
		echo ' ';
		next_post_link('%link', "<i class='icon-right-open-1'></i>" ); 
	?>
</div>