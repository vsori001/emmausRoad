jQuery(window).load(function(){

	jQuery('.dslca-tut-modal-content').animate({ top : '50%', opacity : 1 }, 400 );

});