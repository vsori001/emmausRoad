<?php

$dslc_plugin_options = array(); // Holds all plugin options

include DSLC_PO_FRAMEWORK_ABS . '/inc/options.php';
include DSLC_PO_FRAMEWORK_ABS . '/inc/functions.php';
include DSLC_PO_FRAMEWORK_ABS . '/inc/display-options.php';
include DSLC_PO_FRAMEWORK_ABS . '/inc/init.php';